import React from 'react';
import { LayoutDashboard, Users, Settings, LogOut } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';

export default function Sidebar() {
  const location = useLocation();
  
  const isActive = (path: string) => location.pathname === path;
  
  return (
    <div className="w-64 bg-gray-900 h-screen fixed left-0 top-0">
      <div className="p-4">
        <h1 className="text-white text-2xl font-bold mb-8">LeadCruise</h1>
        <nav className="space-y-2">
          <Link
            to="/dashboard"
            className={`flex items-center space-x-3 p-3 rounded-lg ${
              isActive('/dashboard')
                ? 'bg-blue-600 text-white'
                : 'text-gray-300 hover:bg-gray-800'
            }`}
          >
            <LayoutDashboard size={20} />
            <span>Dashboard</span>
          </Link>
          <Link
            to="/leads"
            className={`flex items-center space-x-3 p-3 rounded-lg ${
              isActive('/leads')
                ? 'bg-blue-600 text-white'
                : 'text-gray-300 hover:bg-gray-800'
            }`}
          >
            <Users size={20} />
            <span>Leads</span>
          </Link>
          <Link
            to="/settings"
            className={`flex items-center space-x-3 p-3 rounded-lg ${
              isActive('/settings')
                ? 'bg-blue-600 text-white'
                : 'text-gray-300 hover:bg-gray-800'
            }`}
          >
            <Settings size={20} />
            <span>Settings</span>
          </Link>
        </nav>
      </div>
      <div className="absolute bottom-0 left-0 right-0 p-4">
        <button className="flex items-center space-x-3 text-gray-300 hover:text-white w-full p-3">
          <LogOut size={20} />
          <span>Logout</span>
        </button>
      </div>
    </div>
  );
}