import React from 'react';
import { Phone, Mail, Calendar, Car } from 'lucide-react';
import { Lead } from '../types';

interface LeadCardProps {
  lead: Lead;
  onClick: () => void;
}

export default function LeadCard({ lead, onClick }: LeadCardProps) {
  const getStatusColor = (status: string) => {
    const colors = {
      new: 'bg-blue-100 text-blue-800',
      contacted: 'bg-yellow-100 text-yellow-800',
      qualified: 'bg-green-100 text-green-800',
      'not-interested': 'bg-red-100 text-red-800',
      converted: 'bg-purple-100 text-purple-800',
    };
    return colors[status as keyof typeof colors] || 'bg-gray-100 text-gray-800';
  };

  return (
    <div
      onClick={onClick}
      className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow cursor-pointer"
    >
      <div className="flex justify-between items-start mb-4">
        <h3 className="text-lg font-semibold">{lead.name}</h3>
        <span
          className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(
            lead.status
          )}`}
        >
          {lead.status.charAt(0).toUpperCase() + lead.status.slice(1)}
        </span>
      </div>
      <div className="space-y-2">
        <div className="flex items-center text-gray-600">
          <Phone size={16} className="mr-2" />
          <span>{lead.phone}</span>
        </div>
        <div className="flex items-center text-gray-600">
          <Mail size={16} className="mr-2" />
          <span>{lead.email}</span>
        </div>
        <div className="flex items-center text-gray-600">
          <Car size={16} className="mr-2" />
          <span>{lead.carInterest}</span>
        </div>
        <div className="flex items-center text-gray-600">
          <Calendar size={16} className="mr-2" />
          <span>{new Date(lead.createdAt).toLocaleDateString()}</span>
        </div>
      </div>
    </div>
  );
}