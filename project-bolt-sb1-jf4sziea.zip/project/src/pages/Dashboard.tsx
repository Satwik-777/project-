import React from 'react';
import { BarChart3, Users, TrendingUp, DollarSign } from 'lucide-react';

export default function Dashboard() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-6">Dashboard</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-500">Total Leads</p>
              <h3 className="text-2xl font-bold">1,234</h3>
            </div>
            <div className="bg-blue-100 p-3 rounded-lg">
              <Users className="text-blue-600" />
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-500">Conversion Rate</p>
              <h3 className="text-2xl font-bold">23.5%</h3>
            </div>
            <div className="bg-green-100 p-3 rounded-lg">
              <TrendingUp className="text-green-600" />
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-500">Revenue</p>
              <h3 className="text-2xl font-bold">$534,200</h3>
            </div>
            <div className="bg-yellow-100 p-3 rounded-lg">
              <DollarSign className="text-yellow-600" />
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-500">Active Deals</p>
              <h3 className="text-2xl font-bold">45</h3>
            </div>
            <div className="bg-purple-100 p-3 rounded-lg">
              <BarChart3 className="text-purple-600" />
            </div>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-semibold mb-4">Lead Sources</h3>
          <div className="space-y-4">
            {['Facebook', 'Website', 'Google Ads', 'Referrals'].map((source) => (
              <div key={source} className="flex items-center">
                <div className="flex-1">
                  <p className="text-gray-600">{source}</p>
                </div>
                <div className="w-48 bg-gray-200 rounded-full h-2">
                  <div
                    className="bg-blue-600 h-2 rounded-full"
                    style={{
                      width: `${Math.floor(Math.random() * 100)}%`,
                    }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-semibold mb-4">Recent Activity</h3>
          <div className="space-y-4">
            {[
              'New lead assigned to John Doe',
              'Sarah Smith converted a lead',
              'Follow-up scheduled for tomorrow',
              'New lead from Facebook campaign',
            ].map((activity, index) => (
              <div key={index} className="flex items-start space-x-3">
                <div className="w-2 h-2 rounded-full bg-blue-600 mt-2"></div>
                <p className="text-gray-600">{activity}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}