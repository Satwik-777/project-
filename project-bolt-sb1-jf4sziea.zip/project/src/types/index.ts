export type LeadStatus = 'new' | 'contacted' | 'qualified' | 'not-interested' | 'converted';

export interface Lead {
  id: string;
  name: string;
  email: string;
  phone: string;
  source: string;
  status: LeadStatus;
  notes: string;
  assignedTo: string;
  createdAt: string;
  updatedAt: string;
  carInterest: string;
  budget: number;
  lastContactDate?: string;
}

export interface User {
  id: string;
  name: string;
  role: 'sales' | 'manager';
  email: string;
}